package javaPackage.Interface;

public interface Jump {
    public void jump();  //默认abstract
}
